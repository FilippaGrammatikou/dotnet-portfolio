﻿namespace CSharpFundamentals.Exercises;

public static class Ch20_CalculatorProgram
{
    public static void Run()
    {
        Console.WriteLine("Chapter 20 is a mini-project chapter in the tutorial.");
        Console.WriteLine("Implement it as a separate Console App under: 02-mini-projects");
    }
}
