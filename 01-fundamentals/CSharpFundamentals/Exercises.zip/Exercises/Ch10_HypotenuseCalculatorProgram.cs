﻿namespace CSharpFundamentals.Exercises;

public static class Ch10_HypotenuseCalculatorProgram
{
    public static void Run()
    {
        Console.WriteLine("Chapter 10 is a mini-project chapter in the tutorial.");
        Console.WriteLine("Implement it as a separate Console App under: 02-mini-projects");
    }
}
