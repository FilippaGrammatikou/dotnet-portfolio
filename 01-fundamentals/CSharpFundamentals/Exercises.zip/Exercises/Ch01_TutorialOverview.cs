﻿namespace CSharpFundamentals.Exercises;

public static class Ch01_TutorialOverview
{
    public static void Run()
    {
        // Chapter 1: TutorialOverview
        Console.WriteLine("This is my first line of C# code");
        Console.WriteLine("The goal is to get used to a new environment and GitHub organization");
        Console.Beep();
    }
}
